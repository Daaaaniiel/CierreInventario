import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IngresoAjuste extends JFrame {
    private JTextField txtCodigoAjuste;
    private JTextField txtDescripcionAjuste;
    private JButton btnGuardarAjuste;

    public IngresoAjuste() {
        setTitle("Ingreso de Ajuste");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panelPrincipal = new JPanel();
        GroupLayout layout = new GroupLayout(panelPrincipal);
        panelPrincipal.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        JLabel lblCodigoAjuste = new JLabel("Código:");
        txtCodigoAjuste = new JTextField(7); // Tamaño para "AJ-0001"
        JLabel lblDescripcionAjuste = new JLabel("Descripción:");
        txtDescripcionAjuste = new JTextField(50);

        btnGuardarAjuste = new JButton("Guardar");
        btnGuardarAjuste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCamposAjuste()) {
                    guardarAjuste();
                }
            }
        });

        layout.setHorizontalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(lblCodigoAjuste)
                                .addComponent(lblDescripcionAjuste)
                                .addComponent(btnGuardarAjuste))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(txtCodigoAjuste)
                                .addComponent(txtDescripcionAjuste))
        );

        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(lblCodigoAjuste)
                                .addComponent(txtCodigoAjuste))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(lblDescripcionAjuste)
                                .addComponent(txtDescripcionAjuste))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(btnGuardarAjuste))
        );

        add(panelPrincipal);
        setVisible(true);
    }

    private boolean validarCamposAjuste() {
        if (!validarCodigoAjuste(txtCodigoAjuste.getText().trim())) {
            JOptionPane.showMessageDialog(this, "El código de ajuste debe estar en el formato AJ-0001.");
            return false;
        }

        if (txtDescripcionAjuste.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese una descripción para el ajuste.");
            return false;
        }

        return true;
    }

    private boolean validarCodigoAjuste(String codigo) {
        // Patrón para validar el código de ajuste AJ-0001
        String regex = "^AJ-\\d{4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(codigo);
        return matcher.matches();
    }

    private void guardarAjuste() {
        String codigoAjuste = txtCodigoAjuste.getText().trim();
        String descripcionAjuste = txtDescripcionAjuste.getText().trim();
        LocalDate fechaAjuste = LocalDate.now();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO AJUSTES (AJUCODIGO, AJUFECHA, AJUDESCRIPCION) VALUES (?, ?, ?)")) {

            pstmt.setString(1, codigoAjuste);
            pstmt.setDate(2, java.sql.Date.valueOf(fechaAjuste));
            pstmt.setString(3, descripcionAjuste);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Ajuste guardado correctamente.");
            dispose(); // Cerrar la ventana después de guardar
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar el ajuste: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new IngresoAjuste();
    }
}

