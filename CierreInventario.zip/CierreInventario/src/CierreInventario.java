import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public class CierreInventario extends JFrame {
    // Definición de componentes de la GUI
    private JTextField txtDescripcion;
    private JTextField txtUnidadMedida;
    private JTextField txtSaldoInicial;
    private JTextField txtIngresos;
    private JTextField txtEgresos;
    private JTextField txtAjustes;
    private JTextField txtSaldoFinal;
    private JTextField txtSaldoFisico;
    private JTextField codigoAjuste;
    private JTextField txtFecha;
    private JButton btnGuardar;
    private JButton btnAbrirIngresoAjuste;
    private JButton btnEliminar;
    private JButton btnCierreInventario; // Nuevo botón para el cierre de inventario
    private JComboBox<String> comboCodigos;
    private JTable tablaPXA;
    private DefaultTableModel modeloTablaPXA;
    private IngresoAjuste ventanaIngresoAjuste;

    public CierreInventario() {
        // Configuración inicial de la ventana principal
        setTitle("Gestión de Productos");

        // Crear panel principal con fondo
        JPanel panelConFondo = new PanelConFondo("C:/Users/USUARIO/Desktop/hola2.jpg");

        // Definición de etiquetas y campos de texto
        JLabel lblTitulo = new JLabel("CAMPOVERDE SOFT", JLabel.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 42));

        JLabel lblCodigos = new JLabel("Seleccionar Código:");
        comboCodigos = new JComboBox<>();

        JLabel lblDescripcion = new JLabel("Descripción:");
        txtDescripcion = new JTextField(30);
        JLabel lblUnidadMedida = new JLabel("Unidad Medida:");
        txtUnidadMedida = new JTextField(15);

        JLabel lblSaldoInicial = new JLabel("Saldo Inicial:");
        txtSaldoInicial = new JTextField(15);
        JLabel lblIngresos = new JLabel("Ingresos:");
        txtIngresos = new JTextField(15);
        JLabel lblEgresos = new JLabel("Egresos:");
        txtEgresos = new JTextField(15);
        JLabel lblAjustes = new JLabel("Ajustes:");
        txtAjustes = new JTextField(15);
        JLabel lblSaldoFinal = new JLabel("Saldo Final:");
        txtSaldoFinal = new JTextField(15);

        JLabel lblSaldoFisico = new JLabel("Saldo Físico:");
        txtSaldoFisico = new JTextField(15);

        JLabel lblCodigoAjuste = new JLabel("Código Ajuste:");
        codigoAjuste = new JTextField(15);
        JLabel lblFecha = new JLabel("Fecha:");
        txtFecha = new JTextField(15);

        // Botones de la GUI
        btnGuardar = new JButton("Guardar");
        btnAbrirIngresoAjuste = new JButton("Abrir Ingreso Ajuste");
        btnEliminar = new JButton("Eliminar");
        btnCierreInventario = new JButton("Cierre de Inventario"); // Nuevo botón para el cierre de inventario

        // Configuración de la tabla
        modeloTablaPXA = new DefaultTableModel();
        modeloTablaPXA.addColumn("PROCODIGO");
        modeloTablaPXA.addColumn("AJUCODIGO");
        modeloTablaPXA.addColumn("PXADESCRIPCION");
        modeloTablaPXA.addColumn("PXAUNIDADMEDIDA");
        modeloTablaPXA.addColumn("PXAFECHA");
        modeloTablaPXA.addColumn("PXASALDOINICIAL");
        modeloTablaPXA.addColumn("PXAINGRESOS");
        modeloTablaPXA.addColumn("PXAEGRESOS");
        modeloTablaPXA.addColumn("PXAAJUSTES");
        modeloTablaPXA.addColumn("PXASALDOFINAL");
        modeloTablaPXA.addColumn("PXASALDOFISICO");
        modeloTablaPXA.addColumn("PXASALDOTOTAL");

        tablaPXA = new JTable(modeloTablaPXA);
        JScrollPane scrollPane = new JScrollPane(tablaPXA);
        scrollPane.setPreferredSize(new Dimension(1000, 200));

        // Configuración del layout usando GroupLayout en el panel con fondo
        GroupLayout layout = new GroupLayout(panelConFondo);
        panelConFondo.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(lblTitulo)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(lblCodigos)
                        .addComponent(lblDescripcion)
                        .addComponent(lblUnidadMedida)
                        .addComponent(lblSaldoInicial)
                        .addComponent(lblIngresos)
                        .addComponent(lblEgresos)
                        .addComponent(lblAjustes)
                        .addComponent(lblSaldoFinal)
                        .addComponent(lblSaldoFisico)
                        .addComponent(lblCodigoAjuste)
                        .addComponent(lblFecha)
                        .addComponent(btnGuardar)
                        .addComponent(btnAbrirIngresoAjuste)
                        .addComponent(btnEliminar)
                        .addComponent(btnCierreInventario) // Agregar el botón de cierre de inventario
                        .addComponent(scrollPane))
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(comboCodigos)
                        .addComponent(txtDescripcion)
                        .addComponent(txtUnidadMedida)
                        .addComponent(txtSaldoInicial)
                        .addComponent(txtIngresos)
                        .addComponent(txtEgresos)
                        .addComponent(txtAjustes)
                        .addComponent(txtSaldoFinal)
                        .addComponent(txtSaldoFisico)
                        .addComponent(codigoAjuste)
                        .addComponent(txtFecha)))
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(lblTitulo)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigos)
                    .addComponent(comboCodigos))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescripcion)
                    .addComponent(txtDescripcion))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUnidadMedida)
                    .addComponent(txtUnidadMedida))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSaldoInicial)
                    .addComponent(txtSaldoInicial))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIngresos)
                    .addComponent(txtIngresos))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEgresos)
                    .addComponent(txtEgresos))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAjustes)
                    .addComponent(txtAjustes))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSaldoFinal)
                    .addComponent(txtSaldoFinal))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSaldoFisico)
                    .addComponent(txtSaldoFisico))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigoAjuste)
                    .addComponent(codigoAjuste))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFecha)
                    .addComponent(txtFecha))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAbrirIngresoAjuste))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminar))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCierreInventario)) // Botón de cierre de inventario
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(scrollPane))
        );

        // Cargar códigos de productos al iniciar la ventana
        cargarCodigosProducto();

        // Acción para cargar detalles del producto seleccionado en comboCodigos
        comboCodigos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarProductoDetalles();
            }
        });

        // Acción para calcular y actualizar el saldo final al modificar los campos correspondientes
        ActionListener calcularSaldoFinal = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calcularYActualizarSaldoFinal();
            }
        };
        txtSaldoInicial.addActionListener(calcularSaldoFinal);
        txtIngresos.addActionListener(calcularSaldoFinal);
        txtEgresos.addActionListener(calcularSaldoFinal);
        txtAjustes.addActionListener(calcularSaldoFinal);

        // Acción para abrir la ventana de ingreso y ajuste
        btnAbrirIngresoAjuste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (ventanaIngresoAjuste == null || !ventanaIngresoAjuste.isVisible()) {
                    ventanaIngresoAjuste = new IngresoAjuste();
                } else {
                    ventanaIngresoAjuste.toFront();
                }
            }
        });

        // Acción para guardar datos en la tabla PXA
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarDatosEnTablaPXA();
            }
        });

        // Acción para eliminar el registro seleccionado en la tabla PXA
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int opcion = JOptionPane.showConfirmDialog(CierreInventario.this,
                        "¿Estás seguro que deseas eliminar el registro seleccionado?",
                        "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                if (opcion == JOptionPane.YES_OPTION) {
                    eliminarRegistroSeleccionado();
                }
            }
        });

        // Acción para realizar el cierre de inventario
        btnCierreInventario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarCierreInventario();
            }
        });

        // Cargar datos existentes en la tabla PXA al iniciar la ventana
        cargarDatosExistenteTablaPXA();

        // Obtener fecha actual y establecerla en el campo txtFecha
        LocalDate fechaActual = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        txtFecha.setText(fechaActual.format(formatter));

        // Configuración final de la ventana principal
        add(panelConFondo);
        setPreferredSize(new Dimension(1200, 800));
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Método para cargar los códigos de producto desde la base de datos
    private void cargarCodigosProducto() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT PROCODIGO FROM PRODUCTOS")) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String codigo = rs.getString("PROCODIGO");
                comboCodigos.addItem(codigo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para cargar detalles del producto seleccionado en los campos correspondientes
    private void cargarProductoDetalles() {
        String codigoSeleccionado = (String) comboCodigos.getSelectedItem();
        if (codigoSeleccionado != null) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM PRODUCTOS WHERE PROCODIGO = ?")) {
                pstmt.setString(1, codigoSeleccionado);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    txtDescripcion.setText(rs.getString("PRODESCRIPCION"));
                    txtUnidadMedida.setText(rs.getString("PROUNIDADMEDIDA"));
                    txtSaldoInicial.setText(rs.getString("PROSALDOINICIAL"));
                    txtIngresos.setText(rs.getString("PROINGRESOS"));
                    txtEgresos.setText(rs.getString("PROEGRESOS"));
                    txtAjustes.setText(rs.getString("PROAJUSTES"));
                    txtSaldoFinal.setText(rs.getString("PROSALDOFINAL"));
                    txtSaldoFisico.setText(rs.getString("PROSALDOFISICO"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Método para calcular y actualizar el saldo final basado en los campos correspondientes
    private void calcularYActualizarSaldoFinal() {
        BigDecimal saldoInicial = new BigDecimal(txtSaldoInicial.getText().trim());
        BigDecimal ingresos = new BigDecimal(txtIngresos.getText().trim());
        BigDecimal egresos = new BigDecimal(txtEgresos.getText().trim());
        BigDecimal ajustes = new BigDecimal(txtAjustes.getText().trim());

        BigDecimal saldoFinal = saldoInicial.add(ingresos).subtract(egresos).add(ajustes);
        txtSaldoFinal.setText(saldoFinal.toString());
    }

    // Método para guardar datos en la tabla PXA
    private void guardarDatosEnTablaPXA() {
        String procodigo = (String) comboCodigos.getSelectedItem();
        String ajucodigo = codigoAjuste.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String unidadMedida = txtUnidadMedida.getText().trim();
        LocalDate fecha = LocalDate.parse(txtFecha.getText().trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        BigDecimal saldoInicial = new BigDecimal(txtSaldoInicial.getText().trim());
        BigDecimal ingresos = new BigDecimal(txtIngresos.getText().trim());
        BigDecimal egresos = new BigDecimal(txtEgresos.getText().trim());
        BigDecimal ajustes = new BigDecimal(txtAjustes.getText().trim());
        BigDecimal saldoFinal = new BigDecimal(txtSaldoFinal.getText().trim());
        BigDecimal saldoFisico = new BigDecimal(txtSaldoFisico.getText().trim());

        BigDecimal saldoTotal = saldoFisico.subtract(saldoFinal);

        String sql = "INSERT INTO PXA (PROCODIGO, AJUCODIGO, PXADESCRIPCION, PXAUNIDADMEDIDA, PXAFECHA, "
                + "PXASALDOINICIAL, PXAINGRESOS, PXAEGRESOS, PXAAJUSTES, PXASALDOFINAL, PXASALDOFISICO, PXASALDOTOTAL) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, procodigo);
            pstmt.setString(2, ajucodigo);
            pstmt.setString(3, descripcion);
            pstmt.setString(4, unidadMedida);
            pstmt.setDate(5, Date.valueOf(fecha));
            pstmt.setBigDecimal(6, saldoInicial);
            pstmt.setBigDecimal(7, ingresos);
            pstmt.setBigDecimal(8, egresos);
            pstmt.setBigDecimal(9, ajustes);
            pstmt.setBigDecimal(10, saldoFinal);
            pstmt.setBigDecimal(11, saldoFisico);
            pstmt.setBigDecimal(12, saldoTotal);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Datos guardados correctamente en la tabla PXA.");
                limpiarCampos();
                cargarDatosExistenteTablaPXA();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar datos en la tabla PXA: " + ex.getMessage());
        }
    }

    // Método para cargar datos existentes en la tabla PXA al iniciar la ventana
    private void cargarDatosExistenteTablaPXA() {
        modeloTablaPXA.setRowCount(0);

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM PXA");
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Object[] rowData = {
                        rs.getString("PROCODIGO"),
                        rs.getString("AJUCODIGO"),
                        rs.getString("PXADESCRIPCION"),
                        rs.getString("PXAUNIDADMEDIDA"),
                        rs.getDate("PXAFECHA"),
                        rs.getBigDecimal("PXASALDOINICIAL"),
                        rs.getBigDecimal("PXAINGRESOS"),
                        rs.getBigDecimal("PXAEGRESOS"),
                        rs.getBigDecimal("PXAAJUSTES"),
                        rs.getBigDecimal("PXASALDOFINAL"),
                        rs.getBigDecimal("PXASALDOFISICO"),
                        rs.getBigDecimal("PXASALDOTOTAL")
                };
                modeloTablaPXA.addRow(rowData);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar datos de la tabla PXA: " + ex.getMessage());
        }
    }

    // Método para eliminar el registro seleccionado en la tabla PXA
    private void eliminarRegistroSeleccionado() {
        int filaSeleccionada = tablaPXA.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un registro para eliminar.");
            return;
        }

        String procodigo = (String) tablaPXA.getValueAt(filaSeleccionada, 0);
        Date fecha = (Date) tablaPXA.getValueAt(filaSeleccionada, 4);

        String sql = "DELETE FROM PXA WHERE PROCODIGO = ? AND PXAFECHA = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, procodigo);
            pstmt.setDate(2, fecha);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Registro eliminado correctamente.");
                cargarDatosExistenteTablaPXA();
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el registro para eliminar.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar el registro: " + ex.getMessage());
        }
    }

    // Método para realizar el cierre de inventario
    private void realizarCierreInventario() {
    try (Connection conn = DatabaseConnection.getConnection();
         Statement stmt = conn.createStatement()) {

        // Verificar si todos los códigos de productos están en la tabla PXA
        Set<String> codigosProductos = new HashSet<>();
        Set<String> codigosPXA = new HashSet<>();

        // Obtener todos los códigos de productos de la tabla Productos
        String selectProductosSQL = "SELECT PROCODIGO FROM PRODUCTOS";
        ResultSet rsProductos = stmt.executeQuery(selectProductosSQL);
        while (rsProductos.next()) {
            codigosProductos.add(rsProductos.getString("PROCODIGO"));
        }

        // Obtener todos los códigos de productos de la tabla PXA
        String selectPXASQL = "SELECT PROCODIGO FROM PXA";
        ResultSet rsPXA = stmt.executeQuery(selectPXASQL);
        while (rsPXA.next()) {
            codigosPXA.add(rsPXA.getString("PROCODIGO"));
        }

        // Verificar que todos los códigos de productos estén en la tabla PXA
        for (String codigoProducto : codigosProductos) {
            if (!codigosPXA.contains(codigoProducto)) {
                JOptionPane.showMessageDialog(this, "Todos los productos deben estar registrados. No se puede cerrar el inventario.");
                return;
            }
        }

        // Iterar sobre los registros en la tabla PXA y actualizar los saldos finales en la tabla PRODUCTOS
        for (int i = 0; i < modeloTablaPXA.getRowCount(); i++) {
            String procodigo = (String) modeloTablaPXA.getValueAt(i, 0);
            BigDecimal saldoFinal = new BigDecimal(modeloTablaPXA.getValueAt(i, 9).toString()); // Columna PXASALDOFINAL

            // Actualizar el saldo inicial en la tabla PRODUCTOS con el saldo final de PXA
            String updateProFinalSQL = "UPDATE PRODUCTOS SET PROSALDOINICIAL = ?, PROSALDOFINAL = ? WHERE PROCODIGO = ?";
            PreparedStatement pstmtProFinal = conn.prepareStatement(updateProFinalSQL);
            pstmtProFinal.setBigDecimal(1, saldoFinal);
            pstmtProFinal.setBigDecimal(2, saldoFinal);
            pstmtProFinal.setString(3, procodigo);
            pstmtProFinal.executeUpdate();

            // Actualizar los campos PROINGRESOS, PROEGRESOS y PROAJUSTES a 0
            String updateProZeroSQL = "UPDATE PRODUCTOS SET PROINGRESOS = 0, PROEGRESOS = 0, PROAJUSTES = 0 WHERE PROCODIGO = ?";
            PreparedStatement pstmtProZero = conn.prepareStatement(updateProZeroSQL);
            pstmtProZero.setString(1, procodigo);
            pstmtProZero.executeUpdate();
        }

        JOptionPane.showMessageDialog(this, "Cierre de inventario realizado correctamente.");

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error al realizar el cierre de inventario: " + ex.getMessage());
    }
}






    // Método para limpiar los campos de entrada
    private void limpiarCampos() {
        txtDescripcion.setText("");
        txtUnidadMedida.setText("");
        txtSaldoInicial.setText("");
        txtIngresos.setText("");
        txtEgresos.setText("");
        txtAjustes.setText("");
        txtSaldoFinal.setText("");
        txtSaldoFisico.setText("");
        codigoAjuste.setText("");
        txtFecha.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    }
private class PanelConFondo extends JPanel {
        private Image imagenFondo;

        public PanelConFondo(String rutaImagen) {
            // Cargar la imagen de fondo desde un archivo
            ImageIcon icono = new ImageIcon(rutaImagen);
            imagenFondo = icono.getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Dibujar la imagen de fondo en el panel
            g.drawImage(imagenFondo, 0, 0, getWidth(), getHeight(), this);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(1200, 800); // Dimensiones preferidas del panel con fondo
        }
    }
    // Clase principal para iniciar la aplicación
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CierreInventario();
            }
        });
    }
}


class DatabaseConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String USER = "postgres";
    private static final String PASSWORD = "Daniel2023";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}



























